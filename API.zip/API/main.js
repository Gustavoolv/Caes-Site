document.addEventListener('DOMContentLoaded', (event) => {
    const title = document.querySelector("#title");
    const img_dog = document.querySelector(".img_dog");
    const descricao = document.querySelector("#descricao");

    fetch('https://my-json-server.typicode.com/Gustavoolv/DogApi/racas')
        .then(response => response.json())
        .then(data => {
            updateContent(data, 0);
            const links = document.querySelectorAll('.menu-item a');
            links.forEach((link, index) => {
                link.addEventListener('click', (event) => {
                    event.preventDefault();
                    updateContent(data, index);
                });
            });
        })
        .catch(error => {
            console.error('Erro ao obter dados da API:', error);
        });

    function updateContent(data, index) {
        title.innerText = data[index].nome;
        img_dog.src = data[index].url;
        img_dog.alt = data[index].nome;
        descricao.innerText = data[index].descrição;
    }
});